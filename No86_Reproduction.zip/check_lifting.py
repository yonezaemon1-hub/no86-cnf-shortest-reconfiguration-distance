"""Fresh author-side implementation of Sections 2–5, no imported v0.5/reviewer code.
All finite DP candidates checked, including ties; no upper-bound fallback.
"""
from collections import deque, Counter
from itertools import product, combinations_with_replacement
import random, json, time

def valid(F,x):
    return all(any((v in x)==b for v,b in c) for c in F)

def search(F,V,t):
    zero=frozenset(); t=frozenset(t); V=sorted(V)
    assert valid(F,zero) and valid(F,t)
    parent={zero:None}; q=deque([zero])
    while q:
        x=q.popleft()
        for v in V:
            y=x^{v}
            if y not in parent and valid(F,y): parent[y]=(x,v); q.append(y)
    if t not in parent: return None
    p=[]
    while parent[t] is not None: t,v=parent[t]; p.append(v)
    return p[::-1]

def replay(F,n,t,p):
    x=frozenset(); assert valid(F,x)
    for v in p:
        assert 0<=v<n
        x=x^{v}; assert valid(F,x),(F,t,p,x)
    assert x==t

def match(F,V,t,rng):
    adj={(j,b,d):{v for v,bb in c if b==bb and (v in t)==d} for j,c in enumerate(F) for b,d in product((False,True),repeat=2)}
    rm={}; vm={}; order=list(adj); rng.shuffle(order)
    for root in order:
        # alternating BFS to a free variable; flip the augmenting path
        q=deque([root]); seen={root}; pred={}; end=None
        while q and end is None:
            r=q.popleft(); ns=list(adj[r]); rng.shuffle(ns)
            for v in ns:
                if v in pred: continue
                pred[v]=r
                if v not in vm: end=v; break
                rr=vm[v]
                if rr not in seen: seen.add(rr); q.append(rr)
        while end is not None:
            r=pred[end]; old=rm.get(r); rm[r]=end; vm[end]=r; end=old
    reached=set(adj)-set(rm); K=set(); q=deque(reached)
    while q:
        r=q.popleft()
        for v in adj[r]-K:
            K.add(v); assert v in vm
            rr=vm[v]
            if rr not in reached: reached.add(rr); q.append(rr)
    assert len(K)<=4*len(F)
    for r,vs in adj.items():
        if vs-K: assert r in rm and rm[r] in vs-K
    return K,rm

def solve(F,n,t,rng,stats):
    V=set(range(n)); K,M=match(F,V,t,rng); E=t-K; W=V-K-t
    H={j:c for j,c in enumerate(F) if not any(v in E for v,b in c)}
    early={M[j,True,True] for j,c in enumerate(F) if any(v in E and b for v,b in c)}
    late=E-early
    assert early<=E
    H0=[c for c in H.values() if not any(v in W for v,b in c)]
    core=search(H0,K,t&K)
    if core is None: return None
    ps={M[j,True,False] for j,c in H.items() if any(v in W and b for v,b in c)}
    g=len(ps); assert len(K)+g<=4*len(F)
    ep=list(sorted(early)); lp=list(sorted(late)); a=list(sorted(ps)); rng.shuffle(ep); rng.shuffle(lp); rng.shuffle(a)
    upper=ep+a+core+a[::-1]+lp; replay(F,n,t,upper); stats['upper_paths']+=1
    N={v:frozenset(j for j,c in H.items() if (v,False) in c) for v in W}
    P={v:frozenset(j for j,c in H.items() if (v,True) in c) for v in W}
    J=frozenset(H); possible=sorted(set().union(*N.values()))
    best=None
    for z in product((False,True),repeat=len(possible)):
        B=frozenset(j for j,b in zip(possible,z) if b); R=J-B
        U={v for v in W if N[v]&R}
        if len(U)>g: continue
        dp={frozenset():frozenset()}
        for v in sorted(W-U):
            nd={}
            for C,A in dp.items():
                for cc,aa in ((C|(N[v]&B),A),(C|(P[v]&R),A|{v})):
                    if len(aa)<=g and (cc not in nd or len(aa)<len(nd[cc])): nd[cc]=aa
            dp=nd
        for C,A in dp.items():
            if not B<=C: continue
            keep=K|U
            f=[frozenset((v,b) for v,b in H[j] if v in keep) for j in R-C]
            path=search(f,keep,t&keep)
            if path is None: continue
            a=sorted(A); rng.shuffle(a); witness=ep+a+path+a[::-1]+lp
            replay(F,n,t,witness); stats['dp_paths']+=1
            stats['active_paths']+=bool(A); stats['forced_U_paths']+=bool(U)
            if best is None or len(witness)<len(best): best=witness
    assert best is not None and len(best)<=len(upper)
    stats['both_E_W']+=bool(E and W); stats['upper_improved']+=len(best)<len(upper)
    return best

def run():
    rng=random.Random(862026); stats=Counter(); start=time.monotonic()
    def test(F,n,limit=None):
        assert valid(F,frozenset()) and all(not b or (v,False) not in c for c in F for v,b in c)
        # Direct oracle: integer states, literal predicates, full graph BFS once.
        V=range(n); good=[valid(F,frozenset(i for i in V if x>>i&1)) for x in range(1<<n)]
        d={0:0}; q=deque([0])
        while q:
            x=q.popleft()
            for i in V:
                y=x^(1<<i)
                if good[y] and y not in d: d[y]=d[x]+1; q.append(y)
        ts=[x for x in range(1<<n) if good[x]]
        if limit and len(ts)>limit: ts=rng.sample(ts,limit)
        stats['formulas']+=1
        for x in ts:
            t=frozenset(i for i in V if x>>i&1); path=solve(F,n,t,rng,stats)
            assert (None if path is None else len(path))==d.get(x),(F,t,path,d.get(x))
            stats['pairs']+=1; stats['unreachable']+=path is None; stats['detour']+=path is not None and len(path)>len(t)
    test([],5)
    test([frozenset({(0,True),(1,False)}),frozenset({(0,False),(1,True)})],2)
    n=3; cls=[frozenset((i,a==1) for i,a in enumerate(z) if a) for z in product(range(3),repeat=n) if 2 in z]
    for c in cls: test([c],n)
    for c,d in combinations_with_replacement(cls,2): test([c,d],n)
    print('EXHAUSTIVE PASS',json.dumps(stats,sort_keys=True),flush=True)
    for j in range(400):
        n=rng.randint(4,9); m=rng.randint(1,6); F=[]
        while len(F)<m:
            c=frozenset((i,a==1) for i in range(n) if (a:=rng.choices(range(3),weights=(3,2,2))[0]))
            if any(not b for v,b in c): F.append(c)
        test(F,n,10)
    print('RESULT PASS',json.dumps(stats,sort_keys=True),flush=True); print('SECONDS',round(time.monotonic()-start,3))
if __name__=='__main__': run()
