"""No.86 v0.5: independent direct BFS vs matching/DP candidate. Python 3.10+ stdlib."""
import argparse, collections, itertools, json, random, sys, time, traceback
INF = float('inf')

def ok(F,x):
    return all((x&p) or ((~x)&q) for p,q in F)

def direct(F,n):
    # Independent oracle: explicit valid-vertex table, BFS from zero.
    valid=[all(any(((x>>i)&1)==want for i,want in lits) for lits in F) for x in range(1<<n)]
    assert valid[0]
    dist={0:0}; queue=collections.deque([0])
    while queue:
        x=queue.popleft()
        for i in range(n):
            y=x^(1<<i)
            if valid[y] and y not in dist:
                dist[y]=dist[x]+1; queue.append(y)
    return valid,dist

def bits(mask):
    while mask:
        b=mask&-mask; yield b.bit_length()-1; mask^=b

def masks(lits):
    return [(sum(1<<i for i,v in c if v),sum(1<<i for i,v in c if not v)) for c in lits]

def bfs(F,keep,t):
    # Actual original-coordinate masks; graph search only flips retained bits.
    f=[(p&keep,q&keep) for p,q in F]; t&=keep
    if not ok(f,0) or not ok(f,t): return INF,None
    moves=[1<<i for i in bits(keep)]; parent={0:None}; queue=collections.deque([0])
    while queue:
        x=queue.popleft()
        if x==t:
            path=[]
            while parent[x] is not None:
                y=parent[x]; path.append((x^y).bit_length()-1); x=y
            return len(path),path[::-1]
        for b in moves:
            y=x^b
            if y not in parent and ok(f,y): parent[y]=x; queue.append(y)
    return INF,None

def matching(F,n,t):
    allmask=(1<<n)-1; S=allmask^t
    # role order: positive D, negative D, positive S, negative S
    adj=[list(bits(a)) for p,q in F for a in (p&t,q&t,p&S,q&S)]
    mv={}
    def augment(r,seen):
        for v in adj[r]:
            if v in seen: continue
            seen.add(v)
            if v not in mv or augment(mv[v],seen): mv[v]=r; return True
        return False
    for r in range(len(adj)): augment(r,set())
    mr={r:v for v,r in mv.items()}
    reach=set(range(len(adj)))-set(mr); queue=collections.deque(reach); rv=set()
    while queue:
        r=queue.popleft()
        for v in adj[r]:
            if v in rv: continue
            rv.add(v)
            assert v in mv, 'augmenting path after maximum matching'
            rr=mv[v]
            if rr not in reach: reach.add(rr); queue.append(rr)
    K=sum(1<<v for v in rv)
    for r,vs in enumerate(adj):
        if any(not ((K>>v)&1) for v in vs):
            assert r in mr and not ((K>>mr[r])&1)
    assert len(rv)<=4*len(F)
    return K,mr

def candidate(F,n,t):
    allmask=(1<<n)-1; K,mr=matching(F,n,t); D=t&~K; S=allmask&~t&~K
    H=[]; early=set()
    for j,(p,q) in enumerate(F):
        if (p|q)&D:
            if p&D: early.add(mr[4*j])
        else: H.append((j,p,q))
    late=set(bits(D))-early
    H0=[(p,q) for j,p,q in H if not (p|q)&S]
    L,_=bfs(H0,K,t)
    g=sum(bool(p&S) for j,p,q in H)
    assert K.bit_count()+g<=4*len(F)
    meta={'kernel':K.bit_count(),'g':g,'lower':None if L==INF else L+D.bit_count(),'outside':(D|S).bit_count(),'guesses':0}
    if L==INF: return INF,None,meta
    # Explicit upper-bound witness using distinct positive/negative matching roles.
    posS={mr[4*j+2] for j,p,q in H if p&S}
    negS={mr[4*j+3] for j,p,q in H if q&S}
    assert not posS&negS and len(posS)==g
    _,corepath=bfs(H0,K,t)
    upperpath=sorted(early)+sorted(posS)+corepath+sorted(posS)+sorted(late)
    check_path(F,t,upperpath)
    assert len(upperpath)==meta['lower']+2*g
    best=len(upperpath); bestpath=upperpath
    if best==meta['lower']: return best,bestpath,meta
    h=len(H); full=(1<<h)-1
    neg=[0]*n; pos=[0]*n
    for j,(_,p,q) in enumerate(H):
        for v in bits(p&S): pos[v]|=1<<j
        for v in bits(q&S): neg[v]|=1<<j
    ppossible=0
    for v in bits(S): ppossible|=neg[v]
    P=ppossible
    while True:
        R=full^P; U=sum(1<<v for v in bits(S) if neg[v]&R)
        if U.bit_count()<=g:
            meta['guesses']+=1
            # DP tracks negative witness coverage in P AND positive coverage in R.
            # State: covered-clause mask -> (number of selected auxiliaries, selected mask).
            dp={0:(0,0)}
            for v in bits(S&~U):
                nd={}
                for cov,(cost,sel) in dp.items():
                    for cc,cs,ss in ((cov|(neg[v]&P),cost,sel),(cov|(pos[v]&R),cost+1,sel|(1<<v))):
                        if cs<=g and (cc not in nd or cs<nd[cc][0]): nd[cc]=(cs,ss)
                dp=nd
            for cov,(cost,sel) in dp.items():
                if cov&P!=P: continue
                base=D.bit_count()+2*cost
                if base+L>=best: continue
                remaining=R&~cov
                f=[(H[j][1],H[j][2]) for j in bits(remaining)]
                d,path=bfs(f,K|U,t)
                if d==INF or base+d>=best: continue
                selected=list(bits(sel)); witness=sorted(early)+selected+path+selected+sorted(late)
                assert len(witness)==base+d
                check_path(F,t,witness)
                best=base+d; bestpath=witness
        if P==0: break
        P=(P-1)&ppossible
    return best,bestpath,meta

def twin_distance(F,n,t):
    groups={}
    for i in range(n):
        b=1<<i
        sig=(bool(t&b),tuple((bool(p&b),bool(q&b)) for p,q in F))
        groups.setdefault(sig,[]).append(i)
    keep=0; offset=0
    for (changes,_),vs in groups.items():
        keep|=sum(1<<v for v in vs[:2])
        if changes: offset+=max(0,len(vs)-2)
    d,_=bfs(F,keep,t)
    return d+offset,keep.bit_count()<n

def check_path(F,t,path):
    x=0; assert ok(F,x)
    for v in path:
        x^=1<<v
        assert ok(F,x), ('invalid lifted path',x,path,F,t)
    assert x==t, ('wrong endpoint',x,t,path)

def run(args):
    rng=random.Random(args.seed); stats=collections.Counter(); start=time.monotonic()
    def test(n,lits,targets=None):
        F=masks(lits); valid,dist=direct(lits,n)
        vs=[i for i,x in enumerate(valid) if x]
        if targets is not None and len(vs)>targets:
            vs=rng.sample(vs,targets)
        stats['formulas']+=1
        for t in vs:
            try:
                expected=dist.get(t,INF); got,path,meta=candidate(F,n,t)
                assert expected==got, ('distance mismatch',expected,got,meta)
                twin,shrunk=twin_distance(F,n,t)
                assert twin==expected, ('twin distance mismatch',twin,expected)
                stats['twin_reduced']+=shrunk
                stats['upper_improved']+=expected!=INF and got<meta['lower']+2*meta['g']
                if got!=INF:
                    assert len(path)==got; check_path(F,t,path)
                    assert meta['lower']<=got<=meta['lower']+2*meta['g']
                stats['pairs']+=1
                stats['unreachable']+=expected==INF
                stats['detour']+=expected!=INF and expected>t.bit_count()
                stats['outside_nonempty']+=meta['outside']>0
                stats['gap_positive']+=expected!=INF and expected>meta['lower']
                stats['dp_guesses']+=meta['guesses']
                stats['dp_cases']+=meta['guesses']>0
                stats['max_kernel']=max(stats['max_kernel'],meta['kernel'])
            except Exception:
                print('FAIL_CASE '+json.dumps({'n':n,'clauses':lits,'t':t,'seed':args.seed}),flush=True)
                raise
    # Directed cases: detour, unreachable, duplicates and variables absent from formula.
    test(3,[[(0,1),(1,1),(2,0)],[(0,0),(1,0),(2,1)]])
    test(2,[[(0,1),(1,0)],[(0,0),(1,1)]])
    test(6,[])
    test(4,[[(0,0),(1,1)],[(1,0),(2,1)],[(2,0),(0,1)]])
    print('DIRECTED PASS '+json.dumps(dict(stats)),flush=True)
    n=3 if args.quick else 4
    cls=[[(i,int(a==1)) for i,a in enumerate(z) if a] for z in itertools.product((0,1,2),repeat=n) if 2 in z]
    for c in cls: test(n,[c])
    for c,d in itertools.combinations_with_replacement(cls,2): test(n,[c,d])
    print('EXHAUSTIVE PASS '+json.dumps(dict(stats)),flush=True)
    # Random normalized CNFs, both sparse and dense, with deliberately repeated roles.
    rounds=50 if args.quick else args.rounds
    for j in range(rounds):
        n=rng.randint(4,9 if args.quick else 12); m=rng.randint(1,7 if args.quick else 9)
        types=rng.randint(1,n) if j%3==0 else n
        typ=[rng.randrange(types) for _ in range(n)] if types<n else list(range(n))
        lits=[]
        for _ in range(m):
            while True:
                z=[rng.choices((0,1,2),weights=(rng.choice((1,3,7)),2,2))[0] for _ in range(types)]
                c=[(i,int(z[typ[i]]==1)) for i in range(n) if z[typ[i]]]
                if any(v==0 for i,v in c): break
            lits.append(c)
        test(n,lits,8 if args.quick else 16)
        if (j+1)%100==0: print('RANDOM_PROGRESS',j+1,'/',rounds,'pairs',stats['pairs'],flush=True)
    print('RANDOM PASS '+json.dumps(dict(stats)),flush=True)
    print('RESULT PASS '+json.dumps(dict(stats),sort_keys=True),flush=True)
    print('ELAPSED_SECONDS %.3f'%(time.monotonic()-start),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--quick',action='store_true'); p.add_argument('--rounds',type=int,default=600); p.add_argument('--seed',type=int,default=8605); a=p.parse_args()
    print('NO86_VERIFICATION v0.5',sys.version.replace('\n',' '),'seed',a.seed,'quick',a.quick,flush=True)
    try: run(a)
    except Exception:
        traceback.print_exc(); print('RESULT FAIL',flush=True); sys.exit(1)
